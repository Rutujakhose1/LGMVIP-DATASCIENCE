# ANIMEWATCH




# Pages

* **Home** - The Home page contains all the 5 sections with that give a gist of each page. 
![alt](./images/Home.jpg)
* **About** - The About page contains information regarding the photographer.
![alt](./images/About.jpg)
* **Portfolio** - The Portfolio page contains all the photos that the photographer presents in a responsive order. 
![alt](./images/Portfolio.jpg)
* **Shop** - The Shop page contains images that could be bought using the link to EyeEm or from that page itself.
![alt](./images/Shop.jpg)


# Website

